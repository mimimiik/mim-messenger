const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');
const path = require('path');
const multer = require('multer');
const fs = require('fs');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
    cors: { origin: "*", methods: ["GET", "POST"] },
    transports: ['websocket', 'polling']
});

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Папка для загрузок
const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir);

// Настройка multer
const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, uploadDir),
    filename: (req, file, cb) => {
        const unique = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, unique + path.extname(file.originalname));
    }
});
const upload = multer({ storage, limits: { fileSize: 50 * 1024 * 1024 } });

// Раздача загруженных файлов
app.use('/uploads', express.static(uploadDir));

// Файлы данных
const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR);
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const CHATS_FILE = path.join(DATA_DIR, 'chats.json');
const MESSAGES_FILE = path.join(DATA_DIR, 'messages.json');

function readJSON(file, defaultVal = []) {
    try {
        const data = fs.readFileSync(file, 'utf8');
        return JSON.parse(data);
    } catch (e) {
        return defaultVal;
    }
}

function writeJSON(file, data) {
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

// Инициализация файлов
if (!fs.existsSync(USERS_FILE)) writeJSON(USERS_FILE, []);
if (!fs.existsSync(CHATS_FILE)) writeJSON(CHATS_FILE, []);
if (!fs.existsSync(MESSAGES_FILE)) writeJSON(MESSAGES_FILE, {});

// Вспомогательные функции
function findUserByUsername(username) {
    const users = readJSON(USERS_FILE);
    return users.find(u => u.username === username);
}

function findUserByEmail(email) {
    const users = readJSON(USERS_FILE);
    return users.find(u => u.email === email);
}

function createUser(userData) {
    const users = readJSON(USERS_FILE);
    const userId = 'user_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6);
    const newUser = { userId, ...userData, status: 'offline', isAdmin: false };
    users.push(newUser);
    writeJSON(USERS_FILE, users);
    return newUser;
}

// ============= REST API =============

// Регистрация / вход по имени
app.post('/api/auth', (req, res) => {
    const { username, password } = req.body;
    if (!username) return res.status(400).json({ error: 'Имя обязательно' });
    let user = findUserByUsername(username);
    if (!user) {
        user = createUser({ username, name: username, avatar: '👤', bio: '', email: username + '@local' });
    }
    // Для простоты пароль не проверяем
    res.json({ success: true, user: { userId: user.userId, username: user.username, name: user.name, avatar: user.avatar, bio: user.bio, isAdmin: user.isAdmin } });
});

// Получить всех пользователей
app.get('/api/users', (req, res) => {
    const users = readJSON(USERS_FILE);
    const userList = users.map(({ userId, username, name, avatar, bio, status }) => ({ userId, username, name, avatar, bio, status }));
    res.json(userList);
});

// Получить чаты пользователя
app.get('/api/chats/:userId', (req, res) => {
    const chats = readJSON(CHATS_FILE);
    const userChats = chats.filter(chat => chat.participants.includes(req.params.userId));
    res.json(userChats);
});

// Получить сообщения чата
app.get('/api/messages/:chatId', (req, res) => {
    const messages = readJSON(MESSAGES_FILE);
    res.json(messages[req.params.chatId] || []);
});

// Создать чат
app.post('/api/chats', (req, res) => {
    const { participants, name, type, owner } = req.body;
    const chatId = 'chat_' + Date.now();
    const newChat = {
        id: chatId,
        participants,
        name: name || 'Чат',
        type: type || 'private',
        createdAt: Date.now(),
        owner: owner || null,
        subscribers: participants
    };
    const chats = readJSON(CHATS_FILE);
    chats.push(newChat);
    writeJSON(CHATS_FILE, chats);
    res.json(newChat);
});

// Обновить профиль
app.post('/api/update-profile', (req, res) => {
    const { userId, name, avatar, bio, theme, wallpaper, encryption } = req.body;
    const users = readJSON(USERS_FILE);
    const index = users.findIndex(u => u.userId === userId);
    if (index !== -1) {
        if (name) users[index].name = name;
        if (avatar) users[index].avatar = avatar;
        if (bio) users[index].bio = bio;
        if (theme) users[index].theme = theme;
        if (wallpaper) users[index].wallpaper = wallpaper;
        if (encryption !== undefined) users[index].encryption = encryption;
        writeJSON(USERS_FILE, users);
        res.json({ success: true, user: users[index] });
    } else {
        res.status(404).json({ error: 'User not found' });
    }
});

// Загрузка файла
app.post('/upload', upload.single('file'), (req, res) => {
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
    const fileUrl = `/uploads/${req.file.filename}`;
    res.json({ url: fileUrl });
});

// Ping для UptimeRobot
app.get('/ping', (req, res) => res.send('pong'));

// ============= WEBSOCKET =============
const onlineUsers = {}; // userId -> socketId

io.on('connection', (socket) => {
    let currentUserId = null;

    socket.on('auth', (userId) => {
        currentUserId = userId;
        onlineUsers[userId] = socket.id;
        // Обновляем статус в users.json
        const users = readJSON(USERS_FILE);
        const user = users.find(u => u.userId === userId);
        if (user) user.status = 'online';
        writeJSON(USERS_FILE, users);
        io.emit('user_status', { userId, status: 'online' });
    });

    socket.on('send_message', (data) => {
        const { chatId, message } = data;
        // Сохраняем сообщение
        const messages = readJSON(MESSAGES_FILE);
        if (!messages[chatId]) messages[chatId] = [];
        messages[chatId].push(message);
        writeJSON(MESSAGES_FILE, messages);
        // Обновляем последнее сообщение в чате
        const chats = readJSON(CHATS_FILE);
        const chat = chats.find(c => c.id === chatId);
        if (chat) {
            chat.lastMessage = message.text;
            chat.lastMessageTime = message.timestamp;
            writeJSON(CHATS_FILE, chats);
        }
        // Рассылаем участникам чата
        if (chat) {
            chat.participants.forEach(participantId => {
                const socketId = onlineUsers[participantId];
                if (socketId) {
                    io.to(socketId).emit('new_message', { chatId, message });
                }
            });
        }
        socket.emit('message_sent', { messageId: message.id });
    });

    socket.on('typing', (data) => {
        const { chatId, userId, isTyping } = data;
        const chats = readJSON(CHATS_FILE);
        const chat = chats.find(c => c.id === chatId);
        if (chat) {
            chat.participants.forEach(participantId => {
                if (participantId !== userId) {
                    const socketId = onlineUsers[participantId];
                    if (socketId) {
                        io.to(socketId).emit('user_typing', { chatId, userId, isTyping });
                    }
                }
            });
        }
    });

    socket.on('disconnect', () => {
        if (currentUserId) {
            delete onlineUsers[currentUserId];
            const users = readJSON(USERS_FILE);
            const user = users.find(u => u.userId === currentUserId);
            if (user) user.status = 'offline';
            writeJSON(USERS_FILE, users);
            io.emit('user_status', { userId: currentUserId, status: 'offline' });
        }
    });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, '0.0.0.0', () => {
    console.log(`✅ МИМ-М сервер запущен на порту ${PORT}`);
});